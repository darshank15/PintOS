
void helloworld()
{
	printf("Hello");
}
